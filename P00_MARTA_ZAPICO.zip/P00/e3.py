from Seq0 import seq_len
print("-----| Exercise 3 |------")
seq = ["U5", "ADA", "FRAT1", "FXN"]
print(seq_len(seq))

