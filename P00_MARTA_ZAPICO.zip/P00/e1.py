from Seq0 import seq_ping

print("Testing the seq_ping() function")
print(seq_ping())