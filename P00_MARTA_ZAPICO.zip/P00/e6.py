from Seq0 import seq_reverse
n = 20
seq = "U5"
print(seq_reverse(seq, n))