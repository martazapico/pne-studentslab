from Seq0 import seq_count_base
base = {"A": 0, "C": 0, "T": 0, "G": 0}
seq = ["U5", "ADA", "FRAT1", "FXN"]
print(seq_count_base(seq, base))
