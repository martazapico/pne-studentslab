from Seq0 import gene_processing
base = {"A": 0, "C": 0, "T": 0, "G": 0}
seq = ["U5", "ADA", "FRAT1", "FXN"]
print(gene_processing(seq, base))