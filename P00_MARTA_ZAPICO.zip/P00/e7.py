from Seq0 import seq_complement
seq = "U5"
print(seq_complement(seq))