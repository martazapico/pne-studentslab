from Seq0 import seq_read_fasta
filename = "U5.txt"
print(seq_read_fasta(filename))


